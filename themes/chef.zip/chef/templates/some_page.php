<?php
/**
* Template Name: Some Page
*
* @package WordPress
* @subpackage Coelix
* @since Coelix 1.0
*/
get_header();

?>

<?php

get_footer();
